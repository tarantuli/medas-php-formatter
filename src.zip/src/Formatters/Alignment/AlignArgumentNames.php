<?php

declare(strict_types=1);

namespace Medas\PhpFormatter\Formatters\Alignment;

use Medas\Core\Attributes\Service;
use Medas\PhpFormatter\{Formatters\BaseFormatter, Formatters\Tokens, Job};
use Medas\PhpTokenizer\{StatementTypeFinder, StatementTypes\FunctionDeclaration, Token};

#[Service]
readonly class AlignArgumentNames extends BaseFormatter
{
    public function __construct(
        private StatementTypeFinder $typeFinder,
    )
    {
    }

    public function priority(): int
    {
        return 400;
    }

    public function format(Job $job): void
    {
        $prefixLengthsPerRootStatement = $this->determinePrefixLengthsPerRootStatement($job);

        foreach ($job->tree->block() as $statement) {
            if ($statement->rootStatement === null) {
                continue;
            }

            if (!$this->typeFinder->for($statement) instanceof FunctionDeclaration) {
                continue;
            }

            $id = spl_object_id($statement->rootStatement);
            $currentLength = 0;

            foreach ($statement as $token) {
                if (!$token->is(Tokens::VARIABLE_STARTERS)) {
                    if (!$this->skipLength($token)) {
                        $currentLength += strlen($token->text) + $token->spaceAfter;
                    }

                    continue;
                }

                if ($token->previous) {
                    $token->previous->extraSpacesAfter += $prefixLengthsPerRootStatement[$id]
                        - $currentLength;
                }
                else {
                    $placeholder = new Token(
                        1,
                        str_repeat(' ', $prefixLengthsPerRootStatement[$id])
                    );

                    $token->statement->prependToken($placeholder);
                }

                break;
            }
        }
    }

    private function determinePrefixLengthsPerRootStatement(Job $job): array
    {
        $prefixLengthsPerRootStatement = [];

        foreach ($job->tree->block() as $statement) {
            if ($statement->rootStatement === null) {
                continue;
            }

            if (!$this->typeFinder->for($statement) instanceof FunctionDeclaration) {
                continue;
            }

            $prefixLength = 0;
            $foundVariable = false;

            foreach ($statement as $token) {
                if ($token->is(Tokens::VARIABLE_STARTERS)) {
                    $foundVariable = true;

                    break;
                }

                if ($this->skipLength($token)) {
                    continue;
                }

                $prefixLength += strlen($token->text) + $token->spaceAfter;
            }

            if (!$foundVariable) {
                continue;
            }

            $id = spl_object_id($statement->rootStatement);

            $prefixLengthsPerRootStatement[$id] = array_key_exists($id, $prefixLengthsPerRootStatement)
                ? max($prefixLength, $prefixLengthsPerRootStatement[$id])
                : $prefixLength;
        }

        return $prefixLengthsPerRootStatement;
    }

    private function skipLength(Token $token): bool
    {
        if ($token->inAttribute || $token->is(T_ATTRIBUTE)) {
            return true;
        }

        if ($token->is([T_COMMENT, T_DOC_COMMENT]) && $token->lineBreakAfter) {
            return true;
        }

        return false;
    }
}
