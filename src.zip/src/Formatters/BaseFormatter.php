<?php

declare(strict_types=1);

namespace Medas\PhpFormatter\Formatters;

abstract readonly class BaseFormatter implements Formatter
{
    public function additionalFormatters(): array
    {
        return [];
    }
}
