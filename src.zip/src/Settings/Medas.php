<?php

declare(strict_types=1);

namespace Medas\PhpFormatter\Settings;

use Medas\PhpFormatter\Formatters\Alignment\AlignArgumentNames;
use Medas\PhpFormatter\Formatters\BlankLines\{
    BlankLineBetweenObjectCreationAndManipulation,
    BlankLinesAfterPropertiesWithAttributes,
    BlankLinesBeforeBlocks,
    BlankLinesBetweenClassSections,
    BlankLinesBetweenStatementGroups,
    MedasElseifWhileCatch,
    NoLineBreakAfterOpenTagWithEcho
};
use Medas\PhpFormatter\Formatters\Imports\NormalizeImports;
use Medas\PhpFormatter\Formatters\LineSplitting\GenericLineSplitter\Sets\{
    ClassDeclarationSet,
    ControlStatementSet,
    GenericLineSet,
    SoftLineSet
};
use Medas\PhpFormatter\Formatters\LineSplitting\KeepOriginalObjectOperatorBreaks;
use Medas\PhpFormatter\Formatters\LineSplitting\LongLineSplitter;
use Medas\PhpFormatter\Formatters\LineSplitting\SoftLineSplitter;
use Medas\PhpFormatter\Formatters\LineSplitting\TrailingCommaSplitter;
use Medas\PhpFormatter\Formatters\Replacements\{UseExitInsteadOfDie, UseUnionNullInsteadOfNullable};
use Medas\PhpFormatter\Formatters\Sorting\ServiceConstructionParameters;
use Medas\PhpFormatter\Preformatters\NoCommentsAtLineEnd;
use Medas\PhpFormatter\Preparsers\ReorderClassElements;
use Medas\ServiceManager\ServiceManager;

class Medas extends Psr12
{
    public function __construct(ServiceManager $serviceManager)
    {
        parent::__construct();

        // Preformatters
        $this->preformatters[] = $serviceManager->resolve(NoCommentsAtLineEnd::class);

        // Preparsers
        $this->preparsers[] = $serviceManager->resolve(ReorderClassElements::class);

        // Formatters
        $this->formatters[] = $serviceManager->resolve(AlignArgumentNames::class);
        $this->formatters[] = $serviceManager->resolve(BlankLineBetweenObjectCreationAndManipulation::class);
        $this->formatters[] = $serviceManager->resolve(BlankLinesAfterPropertiesWithAttributes::class);
        $this->formatters[] = $serviceManager->resolve(BlankLinesBeforeBlocks::class);
        $this->formatters[] = $serviceManager->resolve(BlankLinesBetweenClassSections::class);
        $this->formatters[] = $serviceManager->resolve(BlankLinesBetweenStatementGroups::class);
        $this->formatters[] = $serviceManager->resolve(KeepOriginalObjectOperatorBreaks::class);
        $this->formatters[] = $serviceManager->resolve(LongLineSplitter::class);
        $this->formatters[] = $serviceManager->resolve(MedasElseifWhileCatch::class);
        $this->formatters[] = $serviceManager->resolve(NoLineBreakAfterOpenTagWithEcho::class);
        $this->formatters[] = $serviceManager->resolve(NormalizeImports::class);
        $this->formatters[] = $serviceManager->resolve(ServiceConstructionParameters::class);
        $this->formatters[] = $serviceManager->resolve(SoftLineSplitter::class);
        $this->formatters[] = $serviceManager->resolve(TrailingCommaSplitter::class);
        $this->formatters[] = $serviceManager->resolve(UseExitInsteadOfDie::class);
        $this->formatters[] = $serviceManager->resolve(UseUnionNullInsteadOfNullable::class);

        // Breakpoint sets
        $this->classDeclarationSet = ClassDeclarationSet::instance();
        $this->controlStatementSet = ControlStatementSet::instance();
        $this->genericLineSet = GenericLineSet::instance();
        $this->softLineSet = SoftLineSet::instance();
    }
}
